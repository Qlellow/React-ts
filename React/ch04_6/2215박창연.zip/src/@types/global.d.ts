declare module '@fontsource/*' {}
